<!-- Referenced and Distributed from https://mdbootstrap.com/docs/standard/navigation/headers/#! and https://css-tricks.com/perfect-full-page-background-image/-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<nav class="justify-content-center align-items-center navbar navbar-dark bg-dark">
        <span class="navbar-brand mb-0 h1">Welcome to National Parks Canada</span>
</nav>

<div class="p-5 text-center bg-image text-white"
    style="background: url('mountain.jpg')  fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;"
    
    >
